# esx_menu_default

Redesign of esx_menu_default

Video: Deleted :(

Support: !$trax!#3707

Credits to: Strax

