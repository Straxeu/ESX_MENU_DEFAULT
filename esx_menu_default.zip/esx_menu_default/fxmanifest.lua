fx_version 'adamant'

game 'gta5'

-- 
author 'P1rz5v1l#7530'
description 'Redesign esx_menu_default. Credits: Leanxp'

files {
	'**/**/**/*.*'
}

ui_page {
	'html/ui.html'
}

client_scripts {
	'client/main.lua'
}

server_script 'server/main.lua'